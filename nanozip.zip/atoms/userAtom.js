import {atom} from "recoil"






export const dayState = atom({
  key : 'dayState',
  default : 'Day'
})

export const workspaceState = atom({
  key : 'worksapceState',
  default : 'Team'
})
